# Açaí da Emily — site de delivery

Site estático feito em HTML, CSS e JavaScript. Inclui:
- Cardápio com produtos e preços iniciais sugeridos
- Carrinho com quantidade e total automático
- Montagem de açaí com adicionais
- Taxa de entrega fixa de R$ 5,00
- Formulário de cliente e finalização pelo WhatsApp
- Layout adaptável para celular e computador

## Antes de publicar
1. Abra `index.html` no navegador para testar.
2. Confirme o número do WhatsApp no código, na linha `const WHATSAPP_NUMBER = "5544990402014";`.
   O número informado na conversa pode estar faltando um dígito. Use o número completo no formato internacional, apenas números: 55 + DDD + telefone.
3. Confira se os preços e adicionais sugeridos fazem sentido para sua loja.
4. A taxa de entrega está configurada como R$ 5,00 e o site informa entrega somente em Cidade Gaúcha.

## Publicar no GitHub Pages
1. Entre no GitHub e crie um repositório público chamado `acai-da-emily`.
2. Envie o arquivo `index.html` para a raiz do repositório (upload files).
3. Abra **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione a branch `main` e a pasta `/ (root)`, depois clique em **Save**.
6. Aguarde alguns minutos e abra o endereço que o GitHub Pages mostrar nessa mesma página.

## Como funciona o WhatsApp
O site monta uma mensagem com itens, quantidades, subtotal, entrega, total, dados do cliente e pagamento. O WhatsApp abre com a mensagem preenchida, mas a pessoa ainda precisa tocar em **Enviar**. O site não registra pedidos em um banco de dados e não confirma sozinho se a mensagem foi enviada.
